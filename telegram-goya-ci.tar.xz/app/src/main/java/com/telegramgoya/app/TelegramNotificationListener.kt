package com.telegramgoya.app

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class TelegramNotificationListener : NotificationListenerService() {
    private val recent = LinkedHashMap<String, Long>()
    override fun onCreate() { super.onCreate(); AppContext.context = applicationContext; SpeechController.initialize(this) }
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || !Prefs.enabled(this)) return
        if (sbn.packageName !in setOf("org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram")) return
        val n = sbn.notification
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty().trim()
        val message = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
            ?: return
        if (message.isBlank() || message == "You have a new message") return
        val text = if (title.isBlank()) message else "$title. $message"
        val key = "${sbn.packageName}:${sbn.id}:${sbn.tag}:${text.hashCode()}"
        val now = System.currentTimeMillis()
        synchronized(recent) {
            recent.entries.removeAll { now - it.value > 120_000 }
            if (recent.containsKey(key)) return
            recent[key] = now
            if (recent.size > 100) recent.remove(recent.keys.first())
        }
        SpeechController.enqueue(this, text)
    }
}
