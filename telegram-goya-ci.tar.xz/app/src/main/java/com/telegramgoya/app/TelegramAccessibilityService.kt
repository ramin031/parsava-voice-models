package com.telegramgoya.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityButtonController
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class TelegramAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile private var current: TelegramAccessibilityService? = null
        fun readScreen(): Boolean = current?.readVisibleText() ?: false
    }
    override fun onServiceConnected() {
        super.onServiceConnected()
        current = this
        AppContext.context = applicationContext
        // The accessibility shortcut button remains available inside Telegram.
        accessibilityButtonController.registerAccessibilityButtonCallback(object : AccessibilityButtonController.AccessibilityButtonCallback() {
            override fun onClicked(controller: AccessibilityButtonController) { readVisibleText() }
        })
    }
    override fun onDestroy() { if (current === this) current = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* Explicit user-triggered reads only. */ }
    override fun onInterrupt() { SpeechController.stop() }

    private fun readVisibleText(): Boolean {
        val root = rootInActiveWindow ?: return false
        try {
            if (root.packageName?.toString() !in setOf("org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram")) return false
            val texts = LinkedHashSet<String>()
            fun visit(node: AccessibilityNodeInfo?, depth: Int) {
                if (node == null || depth > 30 || texts.size >= 120) return
                if (node.isVisibleToUser && !node.isPassword) {
                    val str = node.text?.toString()?.trim().orEmpty()
                    if (str.length >= 2) texts.add(str)
                }
                for (i in 0 until node.childCount) {
                    val child = node.getChild(i)
                    if (child != null) {
                        try { visit(child, depth + 1) } finally { child.recycle() }
                    }
                }
            }
            visit(root, 0)
            val content = texts.joinToString(". ").take(14000)
            if (content.isBlank()) return false
            SpeechController.stop()
            SpeechController.enqueue(this, content)
            return true
        } finally { root.recycle() }
    }
}
