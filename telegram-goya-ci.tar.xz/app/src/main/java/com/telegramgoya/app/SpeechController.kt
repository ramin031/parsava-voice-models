package com.telegramgoya.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.ArrayDeque
import java.util.Locale
import java.util.UUID

/** No message text is persisted. Android TTS engines themselves may process network voices remotely. */
object SpeechController {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var running = false
    private var activeId: String? = null
    private var activeText: String? = null
    private var retryOffline = false
    private val queue = ArrayDeque<String>()
    private val locale = Locale.forLanguageTag("fa-IR")

    @Synchronized fun initialize(context: Context) {
        if (tts != null) return
        val app = context.applicationContext
        tts = TextToSpeech(app) { status ->
            main.post {
                ready = status == TextToSpeech.SUCCESS
                if (ready) {
                    tts?.setLanguage(locale)
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String) {}
                        override fun onDone(utteranceId: String) = finish(utteranceId, false)
                        @Deprecated("Deprecated in Java") override fun onError(utteranceId: String) = finish(utteranceId, true)
                        override fun onError(utteranceId: String, errorCode: Int) = finish(utteranceId, true)
                    })
                }
                pump(app)
            }
        }
    }

    @Synchronized fun enqueue(context: Context, text: String) {
        val cleaned = text.trim().replace(Regex("[\\u200B\\u200C]{2,}"), " ")
        if (cleaned.isBlank()) return
        // Long texts are split below the engine-specific input limit.
        cleaned.chunked(2000).forEach { queue.addLast(it) }
        initialize(context)
        main.post { pump(context.applicationContext) }
    }

    @Synchronized fun stop() {
        queue.clear()
        running = false
        activeId = null
        activeText = null
        retryOffline = false
        main.post { tts?.stop() }
    }

    @Synchronized private fun selectVoice(context: Context, offlineOnly: Boolean): Boolean {
        val engine = tts ?: return false
        val candidates = engine.voices?.filter { it.locale.language == "fa" }.orEmpty()
        val offline = candidates.filter { !it.isNetworkConnectionRequired }
        val network = candidates.filter { it.isNetworkConnectionRequired }
        val selected: Voice? = if (offlineOnly || !Prefs.online(context)) offline.firstOrNull() else network.firstOrNull() ?: offline.firstOrNull()
        if (selected != null) return engine.setVoice(selected) == TextToSpeech.SUCCESS
        return engine.setLanguage(locale) >= TextToSpeech.LANG_AVAILABLE
    }

    @Synchronized private fun pump(context: Context) {
        if (!ready || running || queue.isEmpty()) return
        val engine = tts ?: return
        val phrase = queue.removeFirst()
        running = true
        activeText = phrase
        retryOffline = false
        selectVoice(context, offlineOnly = false)
        engine.setSpeechRate(Prefs.rate(context))
        val id = UUID.randomUUID().toString()
        activeId = id
        if (engine.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, id) == TextToSpeech.ERROR) finish(id, true)
    }

    private fun finish(id: String, error: Boolean) {
        main.post {
            synchronized(this) {
                if (id != activeId) return@synchronized
                if (error && !retryOffline) {
                    retryOffline = true
                    val app = AppContext.context ?: return@synchronized
                    if (selectVoice(app, offlineOnly = true)) {
                        val newId = UUID.randomUUID().toString()
                        activeId = newId
                        if (tts?.speak(activeText.orEmpty(), TextToSpeech.QUEUE_FLUSH, null, newId) == TextToSpeech.SUCCESS) return@synchronized
                    }
                }
                running = false
                activeId = null
                activeText = null
                AppContext.context?.let { pump(it) }
            }
        }
    }
}

/** Application context holder; never retains an Activity. */
object AppContext { var context: Context? = null }
