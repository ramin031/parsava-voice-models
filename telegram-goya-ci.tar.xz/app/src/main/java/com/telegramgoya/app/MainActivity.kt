package com.telegramgoya.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppContext.context = applicationContext
        SpeechController.initialize(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(35, 42, 35, 25); layoutDirection = LinearLayout.LAYOUT_DIRECTION_RTL }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        fun label(s: String, size: Float = 17f): TextView = TextView(this).apply { text = s; textSize = size; setPadding(2, 14, 2, 14); root.addView(this) }
        fun button(s: String, click: () -> Unit) = Button(this).apply { text = s; isAllCaps = false; root.addView(this, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)); setOnClickListener { click() } }
        label("تلگرام گویا", 27f).gravity = Gravity.CENTER
        label("نسخه ۱ — مطالب تلگرام را با سرعت ۲× یا ۳× گوش کن")
        val auto = CheckBox(this).apply { text = "خواندن خودکار اعلان‌های جدید"; isChecked = Prefs.enabled(this@MainActivity); setOnCheckedChangeListener { _, v -> Prefs.setEnabled(this@MainActivity, v) }; root.addView(this) }
        val hybrid = CheckBox(this).apply { text = "اولویت صدای شبکه‌ای؛ جایگزین آفلاین"; isChecked = Prefs.online(this@MainActivity); setOnCheckedChangeListener { _, v -> Prefs.setOnline(this@MainActivity, v) }; root.addView(this) }
        label("سرعت خواندن: از ۰٫۵ تا ۳ برابر")
        val rate = SeekBar(this).apply { max = 250; progress = ((Prefs.rate(this@MainActivity) - 0.5f) * 100).toInt().coerceIn(0, 250); setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) Prefs.setRate(this@MainActivity, 0.5f + p / 100f) }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }); root.addView(this) }
        val speedLabel = label("سرعت فعلی: ${"%.1f".format(java.util.Locale.US, Prefs.rate(this))}×")
        val quickSpeed = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; root.addView(this) }
        listOf(1f, 1.5f, 2f, 2.5f, 3f).forEach { speed ->
            Button(this).apply {
                text = "${speed}×"; isAllCaps = false
                quickSpeed.addView(this, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                setOnClickListener {
                    Prefs.setRate(this@MainActivity, speed)
                    rate.progress = ((speed - 0.5f) * 100).toInt()
                    speedLabel.text = "سرعت فعلی: ${"%.1f".format(java.util.Locale.US, speed)}×"
                }
            }
        }
        button("باز کردن تلگرام و شنیدن متن") {
            val launch = packageManager.getLaunchIntentForPackage("org.telegram.messenger")
                ?: packageManager.getLaunchIntentForPackage("org.telegram.messenger.web")
            if (launch == null) Toast.makeText(this, "تلگرام نصب نیست یا نسخه آن شناسایی نشد", Toast.LENGTH_SHORT).show()
            else startActivity(launch)
        }
        button("۱. اجازه دسترسی به اعلان‌ها") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        button("۲. اجازه خواندن متن صفحه") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        button("۳. آزمایش خواندن صفحه فعال") {
            if (!TelegramAccessibilityService.readScreen()) Toast.makeText(this, "تلگرام باید در صفحه فعال باشد و سرویس دسترس‌پذیری روشن باشد. برای خواندن واقعی از داخل تلگرام، کلید میانبر دسترس‌پذیری گویا را هنگام باز بودن تلگرام بزنید.", Toast.LENGTH_LONG).show()
        }
        button("آزمایش صدای فارسی") { SpeechController.enqueue(this, "سلام. من تلگرام گویا هستم. می‌توانی با سرعت دو یا سه برابر، متن‌های تلگرام را گوش کنی.") }
        button("توقف صدا و پاک کردن صف") { SpeechController.stop() }
        label("نکته: برای خواندن متن صفحه، سرویس دسترس‌پذیری گویا را روشن و میانبر دکمه دسترس‌پذیری آن را فعال کنید؛ سپس در خود تلگرام روی دکمه دسترس‌پذیری ضربه بزنید. اگر گوشی این دکمه را ارائه نکند، خواندن صفحه با این روش ممکن نیست.", 13f)
        label("روش سریع: در تلگرام پیام را انتخاب و در صورت وجود دکمه «اشتراک‌گذاری»، تلگرام گویا را انتخاب کن. خواندن صفحه فقط با میانبر دسترس‌پذیری خود اندروید انجام می‌شود.", 13f)
        readSharedText(intent)
        label("حریم خصوصی: پیام‌ها در برنامه ذخیره نمی‌شوند. صدای شبکه‌ای ممکن است متن را به سرویس موتور گفتار گوشی ارسال کند.", 13f)
    }
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readSharedText(intent)
    }
    private fun readSharedText(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND || intent.type != "text/plain") return
        val text = intent.getStringExtra(Intent.EXTRA_TEXT)?.trim().orEmpty()
        if (text.isNotEmpty()) {
            SpeechController.stop()
            SpeechController.enqueue(this, text)
        }
    }
}
