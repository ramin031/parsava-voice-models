package com.telegramgoya.app

import android.content.Context

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("goya_settings", Context.MODE_PRIVATE)
    fun enabled(c: Context) = p(c).getBoolean("notifications", false)
    fun setEnabled(c: Context, enabled: Boolean) = p(c).edit().putBoolean("notifications", enabled).apply()
    fun online(c: Context) = p(c).getBoolean("prefer_network_voice", true)
    fun setOnline(c: Context, enabled: Boolean) = p(c).edit().putBoolean("prefer_network_voice", enabled).apply()
    fun rate(c: Context) = p(c).getFloat("rate", 2.0f)
    fun setRate(c: Context, value: Float) = p(c).edit().putFloat("rate", value.coerceIn(0.5f, 3.0f)).apply()
}
